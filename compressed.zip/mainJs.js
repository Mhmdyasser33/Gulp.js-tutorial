const printHelloWithName = (name) =>{
  return `hello ${name}` ;

}
const printNum = (num) =>{
    return num ;
}