const printNum = (num) =>{
    return num ;
}
const x = 10 ;